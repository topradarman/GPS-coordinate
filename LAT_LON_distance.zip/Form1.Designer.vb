﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(5, 242)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(765, 163)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label48)
        Me.TabPage1.Controls.Add(Me.Label47)
        Me.TabPage1.Controls.Add(Me.Button4)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.Label42)
        Me.TabPage1.Controls.Add(Me.Label43)
        Me.TabPage1.Controls.Add(Me.Label44)
        Me.TabPage1.Controls.Add(Me.Label45)
        Me.TabPage1.Controls.Add(Me.Label33)
        Me.TabPage1.Controls.Add(Me.Label32)
        Me.TabPage1.Controls.Add(Me.Label31)
        Me.TabPage1.Controls.Add(Me.Label30)
        Me.TabPage1.Controls.Add(Me.Label21)
        Me.TabPage1.Controls.Add(Me.Label22)
        Me.TabPage1.Controls.Add(Me.Label23)
        Me.TabPage1.Controls.Add(Me.Label20)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.PictureBox3)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.TextBox17)
        Me.TabPage1.Controls.Add(Me.TextBox16)
        Me.TabPage1.Controls.Add(Me.TextBox15)
        Me.TabPage1.Controls.Add(Me.TextBox14)
        Me.TabPage1.Controls.Add(Me.TextBox13)
        Me.TabPage1.Controls.Add(Me.TextBox12)
        Me.TabPage1.Controls.Add(Me.TextBox11)
        Me.TabPage1.Controls.Add(Me.TextBox10)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.TextBox9)
        Me.TabPage1.Controls.Add(Me.TextBox8)
        Me.TabPage1.Controls.Add(Me.TextBox7)
        Me.TabPage1.Controls.Add(Me.TextBox6)
        Me.TabPage1.Controls.Add(Me.TextBox5)
        Me.TabPage1.Controls.Add(Me.TextBox4)
        Me.TabPage1.Controls.Add(Me.TextBox3)
        Me.TabPage1.Controls.Add(Me.TextBox2)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage1.Size = New System.Drawing.Size(757, 137)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "DMS to Degree "
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(691, 28)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(45, 12)
        Me.Label48.TabIndex = 46
        Me.Label48.Text = "/ Clear"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(681, 11)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(64, 12)
        Me.Label47.TabIndex = 45
        Me.Label47.Text = "Text Copy"
        '
        'Button4
        '
        Me.Button4.ForeColor = System.Drawing.Color.Blue
        Me.Button4.Location = New System.Drawing.Point(680, 75)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(71, 19)
        Me.Button4.TabIndex = 44
        Me.Button4.Text = "Copy-B"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.ForeColor = System.Drawing.Color.Red
        Me.Button3.Location = New System.Drawing.Point(680, 48)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(71, 21)
        Me.Button3.TabIndex = 43
        Me.Button3.Text = "Copy-A"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(392, 78)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(9, 12)
        Me.Label42.TabIndex = 42
        Me.Label42.Text = " "
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(210, 78)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(9, 12)
        Me.Label43.TabIndex = 41
        Me.Label43.Text = " "
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(392, 53)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(9, 12)
        Me.Label44.TabIndex = 40
        Me.Label44.Text = " "
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(210, 53)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(9, 12)
        Me.Label45.TabIndex = 39
        Me.Label45.Text = " "
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(645, 78)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(9, 12)
        Me.Label33.TabIndex = 38
        Me.Label33.Text = " "
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(557, 78)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(9, 12)
        Me.Label32.TabIndex = 37
        Me.Label32.Text = " "
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(645, 53)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(9, 12)
        Me.Label31.TabIndex = 36
        Me.Label31.Text = " "
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(557, 53)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(9, 12)
        Me.Label30.TabIndex = 35
        Me.Label30.Text = " "
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(349, 32)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(9, 12)
        Me.Label21.TabIndex = 34
        Me.Label21.Text = """"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(301, 32)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(9, 12)
        Me.Label22.TabIndex = 33
        Me.Label22.Text = "'"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(255, 32)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(9, 12)
        Me.Label23.TabIndex = 32
        Me.Label23.Text = "°"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(173, 32)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(9, 12)
        Me.Label20.TabIndex = 31
        Me.Label20.Text = """"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(125, 32)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(9, 12)
        Me.Label19.TabIndex = 30
        Me.Label19.Text = "'"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(79, 32)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(9, 12)
        Me.Label18.TabIndex = 29
        Me.Label18.Text = "°"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(593, 32)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(60, 12)
        Me.Label17.TabIndex = 28
        Me.Label17.Text = "Longitude"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(497, 32)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(49, 12)
        Me.Label16.TabIndex = 27
        Me.Label16.Text = "Latitude"
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.InitialImage = CType(resources.GetObject("PictureBox3.InitialImage"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(412, 39)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(76, 64)
        Me.PictureBox3.TabIndex = 26
        Me.PictureBox3.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(569, 115)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 12)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "[km]"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(535, 11)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 12)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Degree"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(276, 11)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 12)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Longitude"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(106, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 12)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Latitude"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(393, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 12)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Distance ="
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Blue
        Me.Label2.Location = New System.Drawing.Point(8, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 12)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Point-B"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(8, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 12)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Point-A"
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(460, 110)
        Me.TextBox17.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(106, 21)
        Me.TextBox17.TabIndex = 17
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(585, 73)
        Me.TextBox16.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(57, 21)
        Me.TextBox16.TabIndex = 16
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(499, 73)
        Me.TextBox15.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(57, 21)
        Me.TextBox15.TabIndex = 15
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(585, 48)
        Me.TextBox14.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(57, 21)
        Me.TextBox14.TabIndex = 14
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(499, 48)
        Me.TextBox13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(57, 21)
        Me.TextBox13.TabIndex = 13
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(332, 73)
        Me.TextBox12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(57, 21)
        Me.TextBox12.TabIndex = 12
        Me.TextBox12.Text = "52.4184"
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(284, 73)
        Me.TextBox11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(42, 21)
        Me.TextBox11.TabIndex = 11
        Me.TextBox11.Text = "32"
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(236, 73)
        Me.TextBox10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(42, 21)
        Me.TextBox10.TabIndex = 10
        Me.TextBox10.Text = "169"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(680, 99)
        Me.Button1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(71, 32)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "Clear"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(157, 73)
        Me.TextBox9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(50, 21)
        Me.TextBox9.TabIndex = 8
        Me.TextBox9.Text = "29.0604"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(109, 73)
        Me.TextBox8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(42, 21)
        Me.TextBox8.TabIndex = 7
        Me.TextBox8.Text = "49"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(61, 73)
        Me.TextBox7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(42, 21)
        Me.TextBox7.TabIndex = 6
        Me.TextBox7.Text = "-9"
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(332, 48)
        Me.TextBox6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(57, 21)
        Me.TextBox6.TabIndex = 5
        Me.TextBox6.Text = "44.904"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(284, 48)
        Me.TextBox5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(42, 21)
        Me.TextBox5.TabIndex = 4
        Me.TextBox5.Text = "58"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(236, 48)
        Me.TextBox4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(42, 21)
        Me.TextBox4.TabIndex = 3
        Me.TextBox4.Text = "-25"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(157, 48)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(50, 21)
        Me.TextBox3.TabIndex = 2
        Me.TextBox3.Text = "28.5336"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(109, 48)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(42, 21)
        Me.TextBox2.TabIndex = 1
        Me.TextBox2.Text = "36"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(61, 48)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(42, 21)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "3"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label49)
        Me.TabPage2.Controls.Add(Me.Label50)
        Me.TabPage2.Controls.Add(Me.Button6)
        Me.TabPage2.Controls.Add(Me.Button5)
        Me.TabPage2.Controls.Add(Me.Label40)
        Me.TabPage2.Controls.Add(Me.Label41)
        Me.TabPage2.Controls.Add(Me.Label38)
        Me.TabPage2.Controls.Add(Me.Label39)
        Me.TabPage2.Controls.Add(Me.Label36)
        Me.TabPage2.Controls.Add(Me.Label37)
        Me.TabPage2.Controls.Add(Me.Label35)
        Me.TabPage2.Controls.Add(Me.Label34)
        Me.TabPage2.Controls.Add(Me.Button2)
        Me.TabPage2.Controls.Add(Me.Label27)
        Me.TabPage2.Controls.Add(Me.Label28)
        Me.TabPage2.Controls.Add(Me.Label29)
        Me.TabPage2.Controls.Add(Me.TextBox34)
        Me.TabPage2.Controls.Add(Me.TextBox33)
        Me.TabPage2.Controls.Add(Me.TextBox32)
        Me.TabPage2.Controls.Add(Me.TextBox31)
        Me.TabPage2.Controls.Add(Me.TextBox30)
        Me.TabPage2.Controls.Add(Me.TextBox29)
        Me.TabPage2.Controls.Add(Me.Label24)
        Me.TabPage2.Controls.Add(Me.Label25)
        Me.TabPage2.Controls.Add(Me.Label26)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.TextBox28)
        Me.TabPage2.Controls.Add(Me.TextBox27)
        Me.TabPage2.Controls.Add(Me.TextBox26)
        Me.TabPage2.Controls.Add(Me.TextBox25)
        Me.TabPage2.Controls.Add(Me.TextBox24)
        Me.TabPage2.Controls.Add(Me.TextBox23)
        Me.TabPage2.Controls.Add(Me.TextBox22)
        Me.TabPage2.Controls.Add(Me.TextBox21)
        Me.TabPage2.Controls.Add(Me.TextBox20)
        Me.TabPage2.Controls.Add(Me.TextBox19)
        Me.TabPage2.Controls.Add(Me.PictureBox2)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.TextBox18)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage2.Size = New System.Drawing.Size(757, 137)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Degree to DMS"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(691, 28)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(45, 12)
        Me.Label49.TabIndex = 88
        Me.Label49.Text = "/ Clear"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(681, 11)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(64, 12)
        Me.Label50.TabIndex = 87
        Me.Label50.Text = "Text Copy"
        '
        'Button6
        '
        Me.Button6.ForeColor = System.Drawing.Color.Blue
        Me.Button6.Location = New System.Drawing.Point(681, 77)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(68, 21)
        Me.Button6.TabIndex = 86
        Me.Button6.Text = "Copy-B"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.ForeColor = System.Drawing.Color.Red
        Me.Button5.Location = New System.Drawing.Point(681, 49)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(69, 21)
        Me.Button5.TabIndex = 85
        Me.Button5.Text = "Copy-A"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(661, 82)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(9, 12)
        Me.Label40.TabIndex = 84
        Me.Label40.Text = " "
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(472, 82)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(9, 12)
        Me.Label41.TabIndex = 83
        Me.Label41.Text = " "
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(661, 54)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(9, 12)
        Me.Label38.TabIndex = 82
        Me.Label38.Text = " "
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(472, 54)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(9, 12)
        Me.Label39.TabIndex = 81
        Me.Label39.Text = " "
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(214, 82)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(9, 12)
        Me.Label36.TabIndex = 80
        Me.Label36.Text = " "
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(126, 82)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(9, 12)
        Me.Label37.TabIndex = 79
        Me.Label37.Text = " "
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(214, 54)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(9, 12)
        Me.Label35.TabIndex = 78
        Me.Label35.Text = " "
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(126, 54)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(9, 12)
        Me.Label34.TabIndex = 77
        Me.Label34.Text = " "
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(681, 103)
        Me.Button2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(68, 30)
        Me.Button2.TabIndex = 76
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(628, 32)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(9, 12)
        Me.Label27.TabIndex = 75
        Me.Label27.Text = """"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(574, 32)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(9, 12)
        Me.Label28.TabIndex = 74
        Me.Label28.Text = "'"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(515, 32)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(9, 12)
        Me.Label29.TabIndex = 73
        Me.Label29.Text = "°"
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(420, 107)
        Me.TextBox34.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(104, 21)
        Me.TextBox34.TabIndex = 72
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(609, 77)
        Me.TextBox33.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(51, 21)
        Me.TextBox33.TabIndex = 71
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(551, 77)
        Me.TextBox32.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(51, 21)
        Me.TextBox32.TabIndex = 70
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(494, 77)
        Me.TextBox31.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(51, 21)
        Me.TextBox31.TabIndex = 69
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(420, 77)
        Me.TextBox30.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(51, 21)
        Me.TextBox30.TabIndex = 68
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(363, 77)
        Me.TextBox29.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(51, 21)
        Me.TextBox29.TabIndex = 67
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(440, 33)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(9, 12)
        Me.Label24.TabIndex = 66
        Me.Label24.Text = """"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(386, 33)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(9, 12)
        Me.Label25.TabIndex = 65
        Me.Label25.Text = "'"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(327, 33)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(9, 12)
        Me.Label26.TabIndex = 64
        Me.Label26.Text = "°"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(465, 7)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(32, 12)
        Me.Label15.TabIndex = 63
        Me.Label15.Text = "DMS"
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(306, 77)
        Me.TextBox28.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(51, 21)
        Me.TextBox28.TabIndex = 62
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(149, 77)
        Me.TextBox27.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(64, 21)
        Me.TextBox27.TabIndex = 61
        Me.TextBox27.Text = "116.3"
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(61, 77)
        Me.TextBox26.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(64, 21)
        Me.TextBox26.TabIndex = 60
        Me.TextBox26.Text = "28.62"
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(609, 49)
        Me.TextBox25.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(51, 21)
        Me.TextBox25.TabIndex = 59
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(551, 49)
        Me.TextBox24.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(51, 21)
        Me.TextBox24.TabIndex = 58
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(494, 49)
        Me.TextBox23.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(51, 21)
        Me.TextBox23.TabIndex = 57
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(420, 49)
        Me.TextBox22.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(51, 21)
        Me.TextBox22.TabIndex = 56
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(363, 49)
        Me.TextBox21.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(51, 21)
        Me.TextBox21.TabIndex = 55
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(306, 49)
        Me.TextBox20.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(51, 21)
        Me.TextBox20.TabIndex = 54
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(149, 49)
        Me.TextBox19.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(64, 21)
        Me.TextBox19.TabIndex = 53
        Me.TextBox19.Text = "133.22"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.InitialImage = CType(resources.GetObject("PictureBox2.InitialImage"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(223, 40)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(76, 64)
        Me.PictureBox2.TabIndex = 52
        Me.PictureBox2.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(527, 112)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(34, 12)
        Me.Label8.TabIndex = 51
        Me.Label8.Text = "[km]"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(115, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 12)
        Me.Label9.TabIndex = 50
        Me.Label9.Text = "Degree"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(152, 31)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(60, 12)
        Me.Label10.TabIndex = 49
        Me.Label10.Text = "Longitude"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(70, 31)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(49, 12)
        Me.Label11.TabIndex = 48
        Me.Label11.Text = "Latitude"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(354, 111)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(64, 12)
        Me.Label12.TabIndex = 47
        Me.Label12.Text = "Distance ="
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.Blue
        Me.Label13.Location = New System.Drawing.Point(8, 80)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(47, 12)
        Me.Label13.TabIndex = 46
        Me.Label13.Text = "Point-B"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.Red
        Me.Label14.Location = New System.Drawing.Point(8, 54)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(47, 12)
        Me.Label14.TabIndex = 45
        Me.Label14.Text = "Point-A"
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(61, 49)
        Me.TextBox18.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(64, 21)
        Me.TextBox18.TabIndex = 44
        Me.TextBox18.Text = "33.3"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(206, 11)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(362, 227)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label46.ForeColor = System.Drawing.Color.Blue
        Me.Label46.Location = New System.Drawing.Point(7, 410)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(197, 12)
        Me.Label46.TabIndex = 2
        Me.Label46.Text = "http://antenna-design.tistory.com"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label51.ForeColor = System.Drawing.Color.Blue
        Me.Label51.Location = New System.Drawing.Point(10, 170)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(133, 12)
        Me.Label51.TabIndex = 3
        Me.Label51.Text = "Google map (Chrome)"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label52.ForeColor = System.Drawing.Color.Blue
        Me.Label52.Location = New System.Drawing.Point(10, 195)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(131, 12)
        Me.Label52.TabIndex = 4
        Me.Label52.Text = "Google map (Explore)"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("굴림", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label53.Location = New System.Drawing.Point(10, 143)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(97, 12)
        Me.Label53.TabIndex = 5
        Me.Label53.Text = "Open the map"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(774, 430)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.Label51)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "GPS Coordinate to Distance Calculator Ver.2.01"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents TextBox27 As TextBox
    Friend WithEvents TextBox26 As TextBox
    Friend WithEvents TextBox25 As TextBox
    Friend WithEvents TextBox24 As TextBox
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents TextBox19 As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents TextBox34 As TextBox
    Friend WithEvents TextBox33 As TextBox
    Friend WithEvents TextBox32 As TextBox
    Friend WithEvents TextBox31 As TextBox
    Friend WithEvents TextBox30 As TextBox
    Friend WithEvents TextBox29 As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label48 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label53 As Label
End Class
